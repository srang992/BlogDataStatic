import flet as ft
from utils import *
import pandas as pd
from custom_controls.cards.list_cards import ArticleCard
from custom_controls.list_upper_section.list_upper_section import TitleText, SubtitleText, SubscriptionButton


async def get_data():
    df = pd.read_csv("data/BlogData.csv")
    return df


async def main(page: ft.Page):
    page.padding = 2
    page.fonts = fonts
    page.title = title
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    lv = ft.ListView(expand=True, spacing=10, padding=15)

    data = await get_data()

    for i in range(0, data.shape[0]):
        lv.controls.append(
            ArticleCard(
                title=data.Title[i],
                title_font_family=title_font,
                desc=data.Description[i],
                desc_font_family=desc_font,
                link=data.Link[i],
            )
        )

    await page.add_async(
        ft.Container(
            ft.Column([
                TitleText(text=title, font_family=title_font),
                SubtitleText(text=subtitle, font_family=desc_font),
                SubscriptionButton(
                    button_text=subscription_button_text,
                    link=subscription_form_link
                ),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER
            ), padding=10,
        ),
        lv
    )


ft.app(target=main, view=ft.WEB_BROWSER, port=8000, assets_dir="assets",)
