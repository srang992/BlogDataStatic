fonts = {
    "Courgette": "fonts/Courgette-Regular.ttf",
    "Alkatra": "fonts/Alkatra-Regular.ttf"
}

title = "Subhradeep's Articles"
subtitle = "Here I listed all of my Data Science Articles I wrote till now. Don't forget to check it out!"
desc_font = "Alkatra"
title_font = "Courgette"
subscription_form_link = "https://forms.gle/Tnbu3sGFdnLuzu518"
subscription_button_text = "Subscribe to My Newsletter"

